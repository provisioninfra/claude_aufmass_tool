/* =============================================================================
 * abgleich-ui.js — Anmeldung, Zustandsanzeige und Rückfragen
 *
 * Wichtigste Eigenschaft: Diese Oberfläche hält niemals jemanden auf. Wer
 * sich nicht anmelden kann - kein Netz, Google gerade nicht erreichbar,
 * Konto noch nicht freigegeben - arbeitet trotzdem weiter. Die Anmeldung
 * ist der Weg zur gemeinsamen Ablage, nicht die Eintrittskarte in das
 * Werkzeug.
 * ========================================================================== */
(function (global) {
  'use strict';

  var A = global.AppKern, Abgleich = global.Abgleich;
  var el = A.el;
  var GOOGLE_SKRIPT = 'https://accounts.google.com/gsi/client';

  var neuZeichnen = null;
  var googleGeladen = false;
  var uebersprungen = false;      /* "ohne Abgleich weiterarbeiten" gewählt */

  /* ---------------------------------------------------------------- */
  /* Google-Anmeldeknopf                                               */
  /* ---------------------------------------------------------------- */
  function googleLaden() {
    if (googleGeladen) { return Promise.resolve(true); }
    return new Promise(function (fertig) {
      var s = document.createElement('script');
      s.src = GOOGLE_SKRIPT;
      s.async = true; s.defer = true;
      s.onload = function () { googleGeladen = true; fertig(true); };
      s.onerror = function () { fertig(false); };
      document.head.appendChild(s);
      /* Nicht ewig warten - ohne Netz kommt nichts. */
      setTimeout(function () { fertig(googleGeladen); }, 8000);
    });
  }

  function knopfZeichnen(ziel, beiAusweis) {
    var z = Abgleich.zustand();
    A.leeren(ziel);
    if (!z.clientId) {
      ziel.appendChild(el('p', { class: 'meldung warn', text:
        'Der Abgleich ist auf dem Server noch nicht eingerichtet: Es fehlt die Google-Client-ID.' }));
      return;
    }
    var platz = el('div', { class: 'google-knopf' });
    ziel.appendChild(platz);

    googleLaden().then(function (da) {
      if (!da || !global.google || !global.google.accounts) {
        A.leeren(platz);
        platz.appendChild(el('p', { class: 'meldung warn', text:
          'Die Anmeldeseite von Google ist nicht erreichbar. Ohne Netz ist das normal – '
          + 'das Werkzeug arbeitet weiter, der Abgleich holt später nach.' }));
        return;
      }
      try {
        global.google.accounts.id.initialize({
          client_id: z.clientId,
          callback: function (antwort) { beiAusweis(antwort.credential); },
          auto_select: false,
          cancel_on_tap_outside: true,
          /* Nur Konten der Organisation anbieten - der Server prüft es
             ohnehin noch einmal, aber so sieht man es schon hier. */
          hd: z.domaene || undefined
        });
        global.google.accounts.id.renderButton(platz, {
          type: 'standard', theme: 'filled_blue', size: 'large',
          text: 'signin_with', shape: 'pill', locale: 'de', width: 280
        });
      } catch (e) {
        platz.appendChild(el('p', { class: 'meldung fehler', text:
          'Die Google-Anmeldung ließ sich nicht aufbauen: ' + (e.message || e) }));
      }
    });
  }

  /* ---------------------------------------------------------------- */
  /* Anmeldeseite                                                      */
  /* ---------------------------------------------------------------- */
  function anmeldeSeite(ziel, eins) {
    var z = Abgleich.zustand();
    var seite = el('div', { class: 'anmelde-seite' });

    seite.appendChild(el('div', { class: 'anmelde-karte' }, [
      eins && eins.logoDataUrl
        ? el('img', { class: 'logo', src: eins.logoDataUrl, alt: eins.firma || '' })
        : null,
      el('h1', { text: (eins && eins.firma) || 'Aufmaß-Tool' }),
      el('p', { class: 'zart', text: (eins && eins.firmaZusatz) || 'Schließanlagen & Zutritt' }),
      el('hr', { class: 'trenner' }),
      el('h2', { style: { marginTop: '0' }, text: 'Anmelden' }),
      el('p', { text: z.domaene
        ? 'Mit dem Google-Konto von ' + z.domaene + '. Danach stehen alle Aufmaße auf jedem Gerät zur Verfügung.'
        : 'Mit dem Google-Konto der Organisation. Danach stehen alle Aufmaße auf jedem Gerät zur Verfügung.' }),
      (function () { var k = el('div', { style: { margin: '18px 0' } });
                     knopfZeichnen(k, anmelden); return k; })(),
      z.letzterFehler ? el('p', { class: 'meldung fehler', text: z.letzterFehler }) : null,
      el('hr', { class: 'trenner' }),
      el('p', { class: 'zart', text:
        'Das Werkzeug arbeitet auch ohne Anmeldung vollständig auf diesem Gerät. '
        + 'Ohne Anmeldung bleiben die Aufmaße aber nur hier.' }),
      el('button', { class: 'klein', text: 'Ohne Abgleich weiterarbeiten',
        onclick: function () { uebersprungen = true; if (neuZeichnen) { neuZeichnen(); } } }),
      el('p', { class: 'zart', style: { marginTop: '16px', fontSize: '12px' }, text: 'Werkzeug-Fassung ' + A.FASSUNG })
    ]));
    ziel.appendChild(seite);
  }

  function anmelden(token) {
    A.toast('Anmeldung wird geprüft …');
    Abgleich.anmelden(token).then(function () {
      var z = Abgleich.zustand();
      A.toast('Angemeldet als ' + (z.benutzer ? z.benutzer.name : '') + '.', 'ok');
      uebersprungen = false;
      Abgleich.start();
      if (neuZeichnen) { neuZeichnen(); }
    }).catch(function (f) {
      A.toast(f.message || 'Die Anmeldung ist gescheitert.', 'fehler');
      if (neuZeichnen) { neuZeichnen(); }
    });
  }

  /* ---------------------------------------------------------------- */
  /* Zustandsanzeige in der Kopfzeile                                  */
  /* ---------------------------------------------------------------- */
  function statusKnoten() {
    var z = Abgleich.zustand();
    var knoten = el('button', { class: 'abgleich-status', title: 'Abgleich',
      onclick: function () { uebersichtZeigen(); } });

    var art, text;
    var antworten = (z.antworten || []).length;
    if (!z.angemeldet) { art = 'aus'; text = 'Nicht angemeldet'; }
    else if (z.konflikte.length) { art = 'frage'; text = z.konflikte.length + ' Rückfrage' + (z.konflikte.length > 1 ? 'n' : ''); }
    else if (antworten) { art = 'antwort'; text = antworten + (antworten === 1 ? ' Rückmeldung' : ' Rückmeldungen'); }
    else if (z.erreichbar === false) { art = 'offline'; text = z.offen ? z.offen + ' wartet' : 'Offline'; }
    else if (z.laeuft) { art = 'laeuft'; text = 'Gleicht ab …'; }
    else if (z.offen) { art = 'offen'; text = z.offen + ' wartet'; }
    else { art = 'fertig'; text = 'Abgeglichen'; }

    knoten.className = 'abgleich-status ' + art;
    knoten.appendChild(el('span', { class: 'punkt' }));
    knoten.appendChild(el('span', { class: 'text', text: text }));
    return knoten;
  }

  function uebersichtZeigen() {
    var z = Abgleich.zustand();
    if (z.konflikte.length) { konfliktDialog(z.konflikte[0]); return; }

    var inhalt = el('div');
    if (z.angemeldet && z.benutzer) {
      inhalt.appendChild(el('p', {}, [
        'Angemeldet als ', el('b', { text: z.benutzer.name }),
        el('span', { class: 'zart', text: '  ·  ' + z.benutzer.email })
      ]));
    } else {
      inhalt.appendChild(el('p', { text: 'Dieses Gerät ist nicht angemeldet. Die Aufmaße bleiben hier.' }));
    }
    /* Wartende Kundenrückmeldungen zuerst - das ist der Grund, warum man
       meist hier hineinschaut. */
    if ((z.antworten || []).length) {
      var liste = el('div', { class: 'antworten-liste' });
      inhalt.appendChild(el('h3', { text: 'Rückmeldungen von Kunden', style: { marginBottom: '2px' } }));
      inhalt.appendChild(el('p', { class: 'zart', style: { marginTop: '0' },
        text: 'Warten auf Ihre Prüfung. Übernommen wird erst, wenn Sie es bestätigen.' }));
      z.antworten.forEach(function (a) {
        liste.appendChild(el('div', { class: 'eintrag' }, [
          el('div', { class: 'fuellen' }, [
            el('b', { text: (a.kunde || 'Aufmaß') + (a.objekt ? ' – ' + a.objekt : '') }),
            el('div', { class: 'zart', style: { fontSize: '13px' },
              text: 'von ' + (a.antwortName || 'dem Kunden') + ' am ' + datum(a.antwortAm) + '  ·  ' + zusammenfassung(a) })
          ]),
          el('button', { class: 'haupt klein', text: 'Prüfen', onclick: function () {
            dlg.schliessen();
            antwortDialog(a);
          } })
        ]));
      });
      inhalt.appendChild(liste);
      inhalt.appendChild(el('hr', { class: 'trenner' }));
    }
    inhalt.appendChild(el('ul', { class: 'liste-schlicht' }, [
      el('li', { text: 'Verbindung: ' + (z.erreichbar === false ? 'nicht erreichbar' : 'in Ordnung') }),
      el('li', { text: 'Noch nicht gesendet: ' + z.offen + (z.offen === 1 ? ' Aufmaß' : ' Aufmaße') }),
      el('li', { text: 'Zuletzt abgeglichen: ' + (z.letzterAbgleich
        ? new Date(z.letzterAbgleich).toLocaleString('de-DE') : 'noch nie') }),
      el('li', { text: 'Fassung: Werkzeug ' + A.FASSUNG + (z.serverVersion ? '  ·  Server-Plugin ' + z.serverVersion : '') })
    ]));
    if (z.letzterFehler) {
      inhalt.appendChild(el('p', { class: 'meldung warn', text: z.letzterFehler }));
    }
    if (z.erreichbar === false) {
      inhalt.appendChild(el('p', { class: 'hinweis', text:
        'Ohne Verbindung wird alles auf dem Gerät gespeichert und später nachgeholt. '
        + 'Es geht nichts verloren.' }));
    }

    var knoepfe = [{ text: 'Schließen' }];
    if (z.angemeldet) {
      knoepfe.unshift({ text: 'Jetzt abgleichen', klasse: 'haupt', schliesst: false,
        aktion: function () { Abgleich.jetzt().then(function () { if (neuZeichnen) { neuZeichnen(); } }); } });
      knoepfe.unshift({ text: 'Abmelden', klasse: 'gefahr', aktion: function () {
        Abgleich.abmelden().then(function () { if (neuZeichnen) { neuZeichnen(); } });
      } });
      knoepfe.splice(2, 0, { fuellen: true });
    }
    var dlg = A.dialogOeffnen({ titel: 'Abgleich', klein: !(z.antworten || []).length, inhalt: inhalt, knoepfe: knoepfe });
  }

  /* ---------------------------------------------------------------- */
  /* Kundenrückmeldung prüfen und übernehmen                           */
  /* ---------------------------------------------------------------- */
  function datum(iso) {
    if (!iso) { return '–'; }
    try { return new Date(iso).toLocaleString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }
    catch (e) { return String(iso).slice(0, 16).replace('T', ' '); }
  }

  function zusammenfassung(a) {
    var n = a.antwortAnzahl || 0, m = a.antwortListen || 0;
    var teile = [n + (n === 1 ? ' Berechtigung' : ' Berechtigungen')];
    if (m) { teile.push(m + (m === 1 ? ' Liste bzw. neue Spalte' : ' Listen bzw. neue Spalten')); }
    if (a.freigabe && a.freigabe.name) {
      teile.push(a.freigabe.art === 'nachtraeglich' ? 'verbindliche Freigabe des vorgelegten Plans' : 'mit verbindlicher Freigabe');
    }
    return teile.join(', ');
  }

  function wertText(w) {
    var K = global.Katalog;
    var zeichen = K && K.berechtigungZeichen ? K.berechtigungZeichen(w) : '';
    var namen = { nein: 'keine Berechtigung', ja: 'berechtigt', zeit: 'zeitlich begrenzt', temp: 'vorübergehend', sperr: 'gesperrt', plan: 'vorgeplant (Reserve)' };
    return (zeichen ? zeichen + '  ' : '') + (namen[w] || w || '–');
  }

  function berichtZeichnen(ziel, b) {
    A.leeren(ziel);
    var zellen = b.aenderungen.filter(function (x) { return x.tuer !== undefined && !x.spalte; });
    var leute = b.aenderungen.filter(function (x) { return x.mitarbeiter; });
    var gruppen = b.aenderungen.filter(function (x) { return x.gruppe; });
    var spalten = b.aenderungen.filter(function (x) { return x.spalte; });
    var freigabe = b.aenderungen.filter(function (x) { return x.freigabe; })[0];
    var ueb = (b.uebersprungen || 0) + (b.listenUebersprungen || 0);
    if (!zellen.length && !leute.length && !gruppen.length && !spalten.length && !freigabe) {
      ziel.appendChild(el('div', { class: 'meldung warn' }, el('div', { text:
        'Diese Rückmeldung enthält keine Änderungen gegenüber dem aktuellen Stand des Aufmaßes'
        + (ueb ? ' – ' + ueb + ' Einträge betreffen Türen, Spalten oder Rechte, die es nicht (mehr) gibt.' : '.') })));
      return;
    }
    if (freigabe) {
      ziel.appendChild(el('div', { class: 'meldung ok' }, el('div', {}, [
        el('b', { text: 'Verbindliche Freigabe durch ' + [freigabe.name, freigabe.funktion].filter(Boolean).join(', ') }),
        el('div', { style: { marginTop: '3px', fontSize: '13px' }, text: freigabe.art === 'nachtraeglich'
          ? 'Der Kunde hat den vorgelegten Plan freigegeben. Mit „Übernehmen“ wird die Freigabe im Aufmaß vermerkt; der Link ist für den Kunden danach gesperrt.'
          : 'Der Kunde hat seine Rückmeldung mit einer verbindlichen Freigabe gesendet. Mit „Übernehmen“ gelten die Änderungen unten als freigegebener Stand; der Link ist für den Kunden danach gesperrt.' })
      ])));
    }
    if (zellen.length) {
      ziel.appendChild(el('h3', { text: zellen.length + (zellen.length === 1 ? ' Berechtigung' : ' Berechtigungen') }));
      var tabelle = el('table');
      tabelle.appendChild(el('thead', {}, el('tr', {}, [
        el('th', { text: 'Tür' }), el('th', { text: 'Spalte' }), el('th', { text: 'Bisher' }), el('th', { text: 'Neu' })
      ])));
      var koerper = el('tbody');
      zellen.forEach(function (x) {
        koerper.appendChild(el('tr', {}, [
          el('td', { text: x.tuer || '–' }), el('td', { text: x.schliessung || '–' }),
          el('td', { text: wertText(x.vorher) }), el('td', { class: 'neu', text: wertText(x.nachher) })
        ]));
      });
      tabelle.appendChild(koerper);
      ziel.appendChild(tabelle);
    }
    function artText(x) { return x.art === 'neu' ? 'neu' : (x.art === 'entfernt' ? 'entfernt' : 'geändert'); }
    if (gruppen.length) {
      ziel.appendChild(el('h3', { text: gruppen.length + (gruppen.length === 1 ? ' Gruppe' : ' Gruppen') }));
      gruppen.forEach(function (x) {
        ziel.appendChild(el('div', { class: 'liste' }, [
          el('b', { text: x.name || '–' }),
          el('span', { class: 'zart', text: '  ' + artText(x) + (x.vorher ? ' (vorher „' + x.vorher + '“)' : '') })
        ]));
      });
    }
    if (leute.length) {
      ziel.appendChild(el('h3', { text: leute.length + ' Mitarbeiter' }));
      leute.forEach(function (x) {
        ziel.appendChild(el('div', { class: 'liste' }, [
          el('b', { text: x.name || '–' }),
          el('span', { class: 'zart', text: '  ' + artText(x) }),
          x.art !== 'entfernt' ? el('div', { class: 'namen', text:
            'Gruppen: ' + ((x.gruppen || []).join(', ') || '–') + '  ·  Medien: ' + (x.medien || '1× (Art offen)') }) : null
        ]));
      });
    }
    if (spalten.length) {
      ziel.appendChild(el('h3', { text: spalten.length + (spalten.length === 1 ? ' neue Spalte' : ' neue Spalten') }));
      spalten.forEach(function (x) {
        ziel.appendChild(el('div', { class: 'liste' }, [
          el('b', { text: (x.art === 'gruppe' ? 'Gruppe ' : 'Mitarbeiter ') + (x.name || '–') }),
          el('span', { class: 'zart', text: '  ' + x.zellen + (x.zellen === 1 ? ' Berechtigung' : ' Berechtigungen')
            + (x.vorhanden ? ' (Spalte gab es schon – Berechtigungen werden ergänzt)' : '') })
        ]));
      });
    }
    if (ueb) {
      ziel.appendChild(el('p', { class: 'hinweis', text:
        ueb + ' Einträge betreffen Türen, Spalten oder Rechte, die es nicht (mehr) gibt – sie werden übersprungen.' }));
    }
  }

  function antwortDialog(eintrag, beiFertig) {
    var inhalt = el('div');
    inhalt.appendChild(el('div', { class: 'meldung info' }, el('div', {}, [
      el('b', { text: (eintrag.kunde || 'Aufmaß') + (eintrag.objekt ? ' – ' + eintrag.objekt : '') }),
      el('div', { style: { marginTop: '4px', fontSize: '13.5px' },
        text: 'Übertragen von ' + (eintrag.antwortName || 'dem Kunden') + ' am ' + datum(eintrag.antwortAm)
              + (eintrag.antwortNr > 1 ? '  ·  Rückmeldung Nr. ' + eintrag.antwortNr : '') }),
      eintrag.antwortAnmerkung ? el('div', { style: { marginTop: '6px', fontSize: '13.5px', whiteSpace: 'pre-wrap' } }, [
        el('b', { text: 'Anmerkung: ' }), eintrag.antwortAnmerkung
      ]) : null
    ])));
    var bericht = el('div', { class: 'antwort-bericht' }, el('p', { class: 'zart', text: 'Bericht wird erstellt …' }));
    inhalt.appendChild(bericht);
    inhalt.appendChild(el('p', { class: 'hinweis', text:
      'Am Aufmaß ändert sich erst etwas, wenn Sie unten auf „Übernehmen“ tippen. '
      + '„Verwerfen“ legt die Rückmeldung ab, ohne sie zu übernehmen – der Kunde kann jederzeit erneut übertragen.' }));

    var laeuft = false;
    function fertig(schliessen, text) {
      A.toast(text, 'ok');
      schliessen();
      if (beiFertig) { try { beiFertig(); } catch (e) {} }
      if (neuZeichnen) { neuZeichnen(); }
    }
    A.dialogOeffnen({
      titel: 'Rückmeldung des Kunden prüfen', inhalt: inhalt,
      knoepfe: [
        { text: 'Später' },
        { text: 'Verwerfen', klasse: 'gefahr', schliesst: false, aktion: function (schliessen) {
          if (laeuft) { return false; }
          A.bestaetigen('Rückmeldung verwerfen?',
            'Die Rückmeldung wird abgelegt, ohne das Aufmaß zu ändern. Der Kunde kann jederzeit erneut übertragen.',
            'Verwerfen').then(function (ja) {
            if (!ja) { return; }
            laeuft = true;
            Abgleich.antwortVerwerfen(eintrag.code).then(function () {
              fertig(schliessen, 'Rückmeldung verworfen.');
            }).catch(function (f) {
              laeuft = false;
              A.toast(fehlerText(f, 'Das ließ sich gerade nicht ablegen.'), 'fehler');
              if (f && f.status === 409) { schliessen(); if (neuZeichnen) { neuZeichnen(); } }
            });
          });
          return false;
        } },
        { fuellen: true },
        { text: 'Übernehmen', klasse: 'haupt', schliesst: false, aktion: function (schliessen) {
          if (laeuft) { return false; }
          laeuft = true;
          Abgleich.antwortUebernehmen(eintrag.code).then(function (b) {
            fertig(schliessen, global.Freigabe.berichtText(b) + '.');
          }).catch(function (f) {
            laeuft = false;
            A.toast(fehlerText(f, 'Die Übernahme ist gescheitert.'), 'fehler');
            if (f && f.status === 409) { schliessen(); if (neuZeichnen) { neuZeichnen(); } }
          });
          return false;
        } }
      ]
    });
    Abgleich.antwortVorschau(eintrag.code).then(function (v) {
      berichtZeichnen(bericht, v.bericht);
    }).catch(function (f) {
      A.leeren(bericht);
      bericht.appendChild(el('div', { class: 'meldung warn' }, el('div', { text: f.message || 'Der Bericht ließ sich nicht erstellen.' })));
    });
  }

  /* Hinweis im Schließplan, wenn zu diesem Aufmaß eine Rückmeldung wartet. */
  function antwortenHinweis(projektId, beiFertig) {
    var liste = Abgleich.antwortenFuer ? Abgleich.antwortenFuer(projektId) : [];
    if (!liste.length) { return null; }
    var kasten = el('div', { class: 'meldung info antworten-hinweis' });
    liste.forEach(function (a) {
      kasten.appendChild(el('div', { class: 'zeile-verteilt', style: { width: '100%', gap: '10px' } }, [
        el('div', { class: 'fuellen' }, [
          el('b', { text: (a.freigabe && a.freigabe.name) ? 'Verbindliche Freigabe des Kunden liegt vor' : 'Rückmeldung des Kunden liegt vor' }),
          el('div', { style: { fontSize: '13px', marginTop: '2px' },
            text: 'von ' + (a.antwortName || 'dem Kunden') + ' am ' + datum(a.antwortAm) + '  ·  ' + zusammenfassung(a) })
        ]),
        el('button', { class: 'haupt klein', text: 'Prüfen und übernehmen',
          onclick: function () { antwortDialog(a, beiFertig); } })
      ]));
    });
    return kasten;
  }

  /* ---------------------------------------------------------------- */
  /* Rückfrage bei echtem Konflikt                                     */
  /* ---------------------------------------------------------------- */
  function konfliktDialog(satz) {
    var wahl = {};
    satz.konflikte.forEach(function (k) { wahl[k.id] = 'meins'; });

    var liste = el('div', { class: 'konflikt-liste' });

    function zeichnen() {
      A.leeren(liste);
      satz.konflikte.forEach(function (k) {
        var zeile = el('div', { class: 'konflikt' });
        zeile.appendChild(el('div', { class: 'wo' }, [
          el('span', { class: 'bereich', text: k.bereich }),
          el('b', { text: k.gegenstand }),
          el('span', { class: 'zart', text: ' · ' + k.feldName })
        ]));
        [['meins', 'Deine Fassung', k.meins], ['server', satz.wer + ': ', k.server]].forEach(function (x) {
          var gewaehlt = wahl[k.id] === x[0];
          zeile.appendChild(el('button', {
            class: 'fassung' + (gewaehlt ? ' gewaehlt' : ''),
            'aria-pressed': gewaehlt ? 'true' : 'false',
            onclick: function () { wahl[k.id] = x[0]; zeichnen(); }
          }, [
            el('span', { class: 'herkunft', text: x[1] }),
            el('span', { class: 'wert', text: anzeige(x[2]) })
          ]));
        });
        liste.appendChild(zeile);
      });
    }
    zeichnen();

    var inhalt = el('div', {}, [
      el('p', {}, [
        'Dieses Aufmaß wurde auch von ', el('b', { text: satz.wer }),
        ' geändert. Alles Übrige wurde bereits zusammengeführt – nur bei ',
        satz.konflikte.length === 1 ? 'dieser ' : 'diesen ',
        el('b', { text: satz.konflikte.length === 1 ? 'einen' : String(satz.konflikte.length) }),
        satz.konflikte.length === 1 ? ' Angabe' : ' Angaben',
        ' wurde beidseitig etwas anderes eingetragen.'
      ]),
      el('div', { class: 'knopfleiste', style: { marginBottom: '12px' } }, [
        el('button', { class: 'klein', text: 'Überall meine Fassung', onclick: function () {
          satz.konflikte.forEach(function (k) { wahl[k.id] = 'meins'; }); zeichnen();
        } }),
        el('button', { class: 'klein', text: 'Überall ' + satz.wer, onclick: function () {
          satz.konflikte.forEach(function (k) { wahl[k.id] = 'server'; }); zeichnen();
        } })
      ]),
      liste
    ]);

    A.dialogOeffnen({
      titel: 'Rückfrage zu „' + satz.name + '“',
      inhalt: inhalt,
      knoepfe: [
        { text: 'Später entscheiden' },
        { fuellen: true },
        { text: 'Übernehmen', klasse: 'haupt', aktion: function () {
            Abgleich.konfliktAufloesen(satz.projektId, wahl).then(function () {
              A.toast('Zusammengeführt.', 'ok');
              if (neuZeichnen) { neuZeichnen(); }
            }).catch(function (f) {
              A.toast('Zusammenführen fehlgeschlagen: ' + ((f && f.message) || 'unbekannter Fehler') + '. Die Rückfrage bleibt bestehen.', 'fehler');
            });
          } }
      ]
    });
  }

  /* Eine Netzstörung heißt im Browser „Failed to fetch“ - das sagt
     niemandem etwas. */
  function fehlerText(f, sonst) {
    if (f && !f.status) { return 'Keine Verbindung zum Server. Bitte später erneut versuchen.'; }
    return (f && f.message) || sonst;
  }

  function anzeige(wert) {
    if (wert === '' || wert === null || wert === undefined) { return '(leer)'; }
    if (wert === true) { return 'ja'; }
    if (wert === false) { return 'nein'; }
    if (typeof wert === 'object') { try { return JSON.stringify(wert); } catch (e) { return '…'; } }
    return String(wert);
  }

  /* ---------------------------------------------------------------- */
  /* Zuständige je Aufmaß                                              */
  /* ---------------------------------------------------------------- */
  function zustaendigeKarte(projekt, beiAenderung) {
    var z = Abgleich.zustand();
    if (!z.angemeldet) { return null; }

    var karte = el('div', { class: 'karte' });
    karte.appendChild(el('h2', { style: { marginTop: '0' }, text: 'Zuständig für dieses Aufmaß' }));
    var bereich = el('div');
    karte.appendChild(bereich);
    karte.appendChild(el('p', { class: 'hinweis', text:
      'Alle sehen jedes Aufmaß. Ändern darf nur, wer hier eingetragen ist.' }));

    bereich.appendChild(el('p', { class: 'zart', text: 'Wird geladen …' }));
    Promise.all([Abgleich.benutzerListe(), Abgleich.zustaendigeLesen(projekt.id)])
      .then(function (beides) {
        var alle = beides[0], antwort = beides[1];
        var gesetzt = antwort.zustaendige;
        A.leeren(bereich);
        if (!antwort.abgeglichen) {
          bereich.appendChild(el('p', { class: 'hinweis', text:
            'Dieses Aufmaß ist noch nicht abgeglichen. Sobald es auf dem Server liegt, '
            + 'lässt sich hier festlegen, wer es ändern darf.' }));
          return;
        }
        if (!alle.length) {
          bereich.appendChild(el('p', { class: 'zart', text: 'Noch keine weiteren Zugänge vorhanden.' }));
          return;
        }
        var gewaehlt = {};
        gesetzt.forEach(function (x) { gewaehlt[x.id] = true; });
        var chips = el('div', { class: 'chips' });
        alle.forEach(function (b) {
          var knopf = el('button', {
            class: 'chip' + (gewaehlt[b.id] ? ' gesetzt' : ''),
            'aria-pressed': gewaehlt[b.id] ? 'true' : 'false',
            text: b.name,
            onclick: function () {
              gewaehlt[b.id] = !gewaehlt[b.id];
              knopf.classList.toggle('gesetzt', !!gewaehlt[b.id]);
              knopf.setAttribute('aria-pressed', gewaehlt[b.id] ? 'true' : 'false');
              var ids = Object.keys(gewaehlt).filter(function (k) { return gewaehlt[k]; });
              Abgleich.zustaendigeSetzen(projekt.id, ids).then(function () {
                A.toast('Zuständigkeit gespeichert.', 'ok');
                if (beiAenderung) { beiAenderung(); }
              }).catch(function (f) {
                A.toast(f.message || 'Die Zuständigkeit ließ sich nicht ändern.', 'fehler');
              });
            }
          });
          chips.appendChild(knopf);
        });
        bereich.appendChild(chips);
      })
      .catch(function () {
        A.leeren(bereich);
        bereich.appendChild(el('p', { class: 'zart', text: 'Die Zuständigkeiten sind gerade nicht abrufbar.' }));
      });
    return karte;
  }

  /* ---------------------------------------------------------------- */
  /* Zugangsschlüssel für Programme und Claude Code                    */
  /* ---------------------------------------------------------------- */
  var ANBINDUNG_DATEI = 'aufmass-anbindung.zip';

  function basisAdresse() {
    var b = Abgleich.basis ? Abgleich.basis() : '';
    if (!b && /^https?:/.test(location.protocol)) { b = location.origin; }
    return b || 'https://www.provision-infra.de';
  }

  function kopierKnopf(text, beschriftung) {
    var knopf = el('button', { class: 'klein', text: beschriftung || 'Kopieren', onclick: function () {
      var fertig = function () { knopf.textContent = 'Kopiert ✓'; setTimeout(function () { knopf.textContent = beschriftung || 'Kopieren'; }, 2500); };
      var vonHand = function () { knopf.textContent = 'Bitte von Hand markieren'; };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(fertig).catch(vonHand);
      } else {
        var hilf = el('textarea', { style: { position: 'absolute', left: '-9999px' } }); hilf.value = text;
        document.body.appendChild(hilf); hilf.select();
        try { document.execCommand('copy'); fertig(); } catch (e) { vonHand(); }
        document.body.removeChild(hilf);
      }
    } });
    return knopf;
  }

  function befehlKasten(ueberschrift, text) {
    return el('div', { style: { marginTop: '10px' } }, [
      el('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '8px' } }, [
        el('b', { text: ueberschrift }), kopierKnopf(text)
      ]),
      el('pre', { class: 'befehl-kasten', text: text })
    ]);
  }

  /* Der Schlüssel wird genau einmal gezeigt - danach kennt ihn nur noch, wer ihn kopiert hat. */
  function schluesselZeigen(e, beiFertig) {
    var geheim = e.schluessel, eintrag = e.eintrag || {};
    var basis = basisAdresse();
    var mcpBefehl = 'claude mcp add aufmass --env AUFMASS_URL=' + basis + ' --env AUFMASS_SCHLUESSEL=' + geheim
      + ' -- node ~/aufmass-anbindung/aufmass-mcp.js';
    var curlBefehl = 'curl -H "Authorization: Bearer ' + geheim + '" ' + basis + '/wp-json/aufmass/v1/projekte';
    var feld = el('input', { type: 'text', class: 'kurzlink-feld', readonly: true, value: geheim, 'aria-label': 'Zugangsschlüssel',
      onclick: function () { feld.select(); } });
    var inhalt = el('div', {}, [
      el('div', { class: 'meldung warn' }, el('div', {}, [
        el('b', { text: 'Dieser Schlüssel wird nur jetzt angezeigt.' }),
        el('div', { style: { marginTop: '4px', fontSize: '13.5px' }, text:
          'Kopieren Sie ihn und bewahren Sie ihn wie ein Passwort auf. Er arbeitet in Ihrem Namen und '
          + (eintrag.rechte === 'schreiben' ? 'darf Aufmaße lesen und ändern. ' : 'darf Aufmaße nur lesen. ')
          + 'Geht er verloren, widerrufen Sie ihn hier und erzeugen einen neuen.' })
      ])),
      el('div', { style: { display: 'flex', gap: '8px', alignItems: 'center', marginTop: '10px' } }, [feld, kopierKnopf(geheim)]),
      el('p', { class: 'zart', style: { marginTop: '6px' }, text: '„' + (eintrag.name || 'Zugangsschlüssel') + '“ · '
        + (eintrag.rechte === 'schreiben' ? 'lesen und schreiben' : 'nur lesen') + ' · gültig bis ' + datum(eintrag.gueltigBis) }),
      el('h3', { style: { marginTop: '16px', marginBottom: '4px' }, text: 'Claude Code anbinden' }),
      el('ol', { style: { paddingLeft: '20px', margin: '6px 0', fontSize: '14px', lineHeight: '1.45' } }, [
        el('li', { text: 'Das Paket „Anbindung“ herunterladen (Knopf in der Karte) und entpacken, z. B. in den Ordner aufmass-anbindung im Benutzerverzeichnis. Node.js 18 oder neuer muss vorhanden sein.' }),
        el('li', { text: 'Den folgenden Befehl im Terminal ausführen – den Pfad am Ende ggf. an den Ordner anpassen.' }),
        el('li', { text: 'In Claude Code dann einfach fragen: „Welche Aufmaße gibt es?“ oder „Lege im Aufmaß Ibsen eine Tür im Erdgeschoss an.“' })
      ]),
      befehlKasten('Befehl für Claude Code', mcpBefehl),
      befehlKasten('Beispiel für eigene Skripte (curl)', curlBefehl)
    ]);
    A.dialogOeffnen({
      titel: 'Neuer Zugangsschlüssel', inhalt: inhalt,
      knoepfe: [{ fuellen: true }, { text: 'Fertig', klasse: 'haupt' }],
      beimSchliessen: beiFertig
    });
    setTimeout(function () { try { feld.focus(); feld.select(); } catch (e) {} }, 50);
  }

  function schluesselDialog(beiFertig) {
    var name = el('input', { type: 'text', value: 'Claude Code', maxlength: '120', placeholder: 'z. B. Claude Code am Arbeitsplatz' });
    var rechte = el('select', {}, [
      el('option', { value: 'schreiben', text: 'Lesen und schreiben (Aufmaße anlegen und ändern)' }),
      el('option', { value: 'lesen', text: 'Nur lesen' })
    ]);
    var tage = el('select', {}, [
      el('option', { value: '30', text: '30 Tage' }),
      el('option', { value: '90', text: '90 Tage' }),
      el('option', { value: '365', text: '1 Jahr' }),
      el('option', { value: '730', text: '2 Jahre (Höchstdauer)' })
    ]);
    tage.value = '365';
    var inhalt = el('div', {}, [
      el('p', { class: 'hinweis', text: 'Der Schlüssel gilt für Sie persönlich: Alles, was ein Programm damit tut, geschieht in Ihrem Namen und unterliegt Ihren Zuständigkeiten. Er lässt sich hier jederzeit widerrufen.' }),
      A.feld('Name', name), A.feld('Rechte', rechte), A.feld('Gültig für', tage)
    ]);
    var laeuft = false;
    A.dialogOeffnen({
      titel: 'Zugangsschlüssel erzeugen', inhalt: inhalt,
      knoepfe: [
        { text: 'Abbrechen' }, { fuellen: true },
        { text: 'Erzeugen', klasse: 'haupt', schliesst: false, aktion: function (schliessen) {
          if (laeuft) { return false; }
          laeuft = true;
          Abgleich.schluesselErzeugen(name.value.trim(), rechte.value, parseInt(tage.value, 10)).then(function (e) {
            schliessen();
            schluesselZeigen(e, beiFertig);
          }).catch(function (f) {
            laeuft = false;
            A.toast(fehlerText(f, 'Der Schlüssel ließ sich nicht erzeugen.'), 'fehler');
          });
          return false;
        } }
      ]
    });
    setTimeout(function () { try { name.focus(); name.select(); } catch (e) {} }, 50);
  }

  function schluesselKarte() {
    var z = Abgleich.zustand();
    if (!z.angemeldet) { return null; }

    var karte = el('div', { class: 'karte', id: 'karte-schluessel' });
    karte.appendChild(el('h2', { style: { marginTop: '0' }, text: 'Zugang für Programme und Claude Code' }));
    karte.appendChild(el('p', { class: 'hinweis', text:
      'Mit einem Zugangsschlüssel arbeiten Programme ohne Browser-Anmeldung mit der gemeinsamen Ablage: '
      + 'Claude Code über den mitgelieferten MCP-Server, eigene Skripte über die Schnittstelle. '
      + 'Jeder Schlüssel gehört einer Person, hat ein Ablaufdatum und kann hier widerrufen werden.' }));
    var liste = el('div', { class: 'schluessel-liste' });
    karte.appendChild(liste);
    var knoepfe = el('div', { class: 'knopfleiste', style: { marginTop: '10px' } });
    knoepfe.appendChild(el('button', { class: 'haupt', text: '+ Neuen Schlüssel erzeugen', onclick: function () { schluesselDialog(laden); } }));
    if (/^https?:/.test(location.protocol)) {
      knoepfe.appendChild(el('a', { class: 'knopf klein', href: ANBINDUNG_DATEI, download: ANBINDUNG_DATEI, text: 'Anbindung herunterladen (ZIP)' }));
    }
    karte.appendChild(knoepfe);

    function laden() {
      A.leeren(liste);
      liste.appendChild(el('p', { class: 'zart', text: 'Wird geladen …' }));
      Abgleich.schluesselListe().then(function (eintraege) {
        A.leeren(liste);
        if (!eintraege.length) {
          liste.appendChild(el('p', { class: 'zart', text: 'Noch kein Schlüssel vorhanden.' }));
          return;
        }
        var tabelle = el('table', { class: 'tabelle schlicht schluessel-tabelle' });
        tabelle.appendChild(el('thead', {}, el('tr', {}, [
          el('th', { text: 'Name' }), el('th', { text: 'Rechte' }), el('th', { text: 'Gültig bis' }), el('th', { text: 'Zuletzt genutzt' }), el('th', { text: '' })
        ])));
        var koerper = el('tbody');
        eintraege.forEach(function (s) {
          koerper.appendChild(el('tr', { class: s.abgelaufen ? 'abgelaufen' : '' }, [
            el('td', { class: 'name' }, [el('b', { text: s.name || 'Zugangsschlüssel' }), s.abgelaufen ? el('span', { class: 'marke-pille gelb', style: { marginLeft: '6px' }, text: 'abgelaufen' }) : null]),
            el('td', { 'data-label': 'Rechte', text: s.rechte === 'schreiben' ? 'lesen und schreiben' : 'nur lesen' }),
            el('td', { 'data-label': 'Gültig bis', text: datum(s.gueltigBis) }),
            el('td', { 'data-label': 'Zuletzt genutzt', text: s.zuletztAm ? datum(s.zuletztAm) : 'noch nie' }),
            el('td', { class: 'aktion' }, el('button', { class: 'klein gefahr', text: 'Widerrufen', onclick: function () {
              A.bestaetigen('Schlüssel „' + (s.name || 'Zugangsschlüssel') + '“ widerrufen?',
                'Programme, die diesen Schlüssel verwenden, verlieren sofort den Zugang. Das lässt sich nicht rückgängig machen.',
                'Widerrufen').then(function (ja) {
                if (!ja) { return; }
                Abgleich.schluesselWiderrufen(s.id).then(function () {
                  A.toast('Schlüssel widerrufen.', 'ok'); laden();
                }).catch(function (f) {
                  A.toast(fehlerText(f, 'Der Schlüssel ließ sich nicht widerrufen.'), 'fehler');
                  if (f && f.status === 404) { laden(); }
                });
              });
            } }))
          ]));
        });
        tabelle.appendChild(koerper);
        liste.appendChild(tabelle);
      }).catch(function (f) {
        A.leeren(liste);
        liste.appendChild(el('p', { class: 'zart', text: f && f.status === 403
          ? 'Schlüssel lassen sich nur in einer Browsersitzung verwalten.'
          : 'Die Schlüssel sind gerade nicht abrufbar.' }));
      });
    }
    laden();
    return karte;
  }

  /* ---------------------------------------------------------------- */
  /* Einhängen                                                         */
  /* ---------------------------------------------------------------- */
  function starten(zeichnen) {
    neuZeichnen = zeichnen;
    return Abgleich.einrichten({
      basisUrl: location.origin,
      beiAenderung: function () { statusAktualisieren(); }
    }).then(function (z) {
      if (z.angemeldet) { Abgleich.start(); }
      return z;
    });
  }

  /* Nur den Statusknopf austauschen, statt die ganze Ansicht neu zu
     bauen - sonst zuckt die Oberfläche bei jedem Abgleich. */
  function statusAktualisieren() {
    var alt = document.querySelector('.abgleich-status');
    if (!alt || !alt.parentNode) { return; }
    alt.parentNode.replaceChild(statusKnoten(), alt);
    hinweisAktualisieren();
  }

  /* Der Hinweis im Schließplan zieht ebenfalls mit, ohne die Ansicht neu
     zu bauen: Trifft eine Rückmeldung ein, während der Plan offen ist,
     erscheint er; ist sie erledigt, verschwindet er. */
  function hinweisAktualisieren() {
    if (!A.Zustand || A.Zustand.ansicht !== 'plan' || !A.Zustand.projekt) { return; }
    var haupt = document.querySelector('main.inhalt .seite');
    if (!haupt) { return; }
    var alt = haupt.querySelector('.antworten-hinweis');
    var neu = antwortenHinweis(A.Zustand.projekt.id, neuZeichnen);
    if (alt && neu) {
      if (alt.textContent !== neu.textContent) { alt.parentNode.replaceChild(neu, alt); }
      return;
    }
    if (alt && !neu) { alt.parentNode.removeChild(alt); return; }
    if (!alt && neu) {
      var kopf = haupt.querySelector('.zeile-verteilt');
      if (kopf && kopf.nextSibling) { haupt.insertBefore(neu, kopf.nextSibling); }
      else { haupt.appendChild(neu); }
    }
  }

  function brauchtAnmeldung() {
    var z = Abgleich.zustand();
    if (uebersprungen) { return false; }
    if (!z.eingerichtet) { return false; }       /* Server kennt keine Anmeldung */
    if (z.erreichbar === false) { return false; } /* ohne Netz nicht im Weg stehen */
    return !z.angemeldet;
  }

  global.AbgleichUI = {
    starten: starten,
    anmeldeSeite: anmeldeSeite,
    statusKnoten: statusKnoten,
    statusAktualisieren: statusAktualisieren,
    brauchtAnmeldung: brauchtAnmeldung,
    konfliktDialog: konfliktDialog,
    antwortDialog: antwortDialog,
    antwortenHinweis: antwortenHinweis,
    zustaendigeKarte: zustaendigeKarte,
    schluesselKarte: schluesselKarte,
    uebersichtZeigen: uebersichtZeigen
  };
})(window);
